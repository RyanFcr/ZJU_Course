#include <stdio.h>
int main(void)
{
	/*---------*/
	printf("****\n");
		printf("***\n");
		printf("**\n");
		printf("*\n");
		system("pause");
		return 0;
}
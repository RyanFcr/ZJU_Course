#include <stdio.h>
int main(void)
{
	/*------------*/
	printf("What is a computer?");
	return 0;
}
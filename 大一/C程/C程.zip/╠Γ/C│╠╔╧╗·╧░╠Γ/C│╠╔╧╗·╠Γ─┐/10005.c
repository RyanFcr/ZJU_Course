#include <stdio.h>
int main(void)
{
	/*------------*/
	printf("Welcome to You!");
	return 0;
}
#include <stdio.h>
int main(void)
{
	/*---------*/
	printf("Programming in C is fun!"
		);
		return 0;
}
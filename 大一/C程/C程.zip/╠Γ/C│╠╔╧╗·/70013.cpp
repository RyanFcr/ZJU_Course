#include <stdio.h>
int main(void)
{
    int i, n, temp;
    int repeat, ri;
    int a[10];

    scanf("%d", &repeat);
    for(ri = 1; ri <= repeat; ri++){
        scanf("%d", &n);
        for(i = 0; i < n; i++)
            scanf("%d", &a[i]);
            for(i=0;i<n/2;i++)
            {
            	temp=a[i];
            	a[i]=a[n-i-1];
            	a[n-i-1]=temp;
            }
        for(i = 0; i < n; i++)
            printf("%d ", a[i]);
        printf("\n");
    }
}

